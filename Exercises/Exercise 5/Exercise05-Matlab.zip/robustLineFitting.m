load('points.mat','x','y');
figure;hold on;
plot(x,y,'kx');
axis equal