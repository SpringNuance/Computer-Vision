## Exercise Round 3

Check out the notebook for the assignments.
