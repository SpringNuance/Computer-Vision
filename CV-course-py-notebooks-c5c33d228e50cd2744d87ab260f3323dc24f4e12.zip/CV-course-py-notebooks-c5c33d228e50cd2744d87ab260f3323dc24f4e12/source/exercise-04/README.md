## Exercise Round 4

Check out the notebook for the assignments.

Boston1.png and Boston2m.png courtesy of M. Sofka (http://www.vision.cs.rpi.edu/gdbicp/dataset/)<br>

Boat1.png and Boat6.png courtesy of K. Mikolajczyk et al. (http://www.robots.ox.ac.uk/~vgg/research/affine/)


