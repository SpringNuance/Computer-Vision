## Exercise Round 7

For this exercise round, you should return the notebook ExerciseRound7.ipynb containing your source codes for Exercise 1 and your written answers to Exercises 2 and 3 (see part[1-3].ipynb). 

Note that for Exercises 2 and 3 you do not need to return any code, just provide written answers to the questions. <br>
First part of the tasks (Ex1-2) can be found in the ExerciseRound7.ipynb. For Ex3 (VGG practical) you need to look at part[1-3].ipynbs.