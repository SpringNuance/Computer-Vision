## Exercise Round 11

Check out the notebook for the assigments.
