## Exercise Round 5

Check out the pdf and the notebook for pen-&-paper and programming tasks, respectively.
